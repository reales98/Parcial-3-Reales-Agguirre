package com.example.p3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
